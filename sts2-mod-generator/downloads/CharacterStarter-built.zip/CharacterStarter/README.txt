CharacterStarter ビルド済み版（STS2 v0.113.1 を参照してビルド）

展開した CharacterStarter フォルダーをゲームの mods フォルダーにコピーし、Modを有効化して起動してください。
初期化時にログに [CharacterStarter] Loaded: 塔の旅人 と出力します。この段階ではプレイ可能なキャラクターは追加されません。コードを変更する場合はC#プロジェクト版を使用してください。
