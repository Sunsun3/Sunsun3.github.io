using MegaCrit.Sts2.Core.Modding;

namespace CharacterStarter;

[ModInitializer(nameof(Initialize))]
public static class ModEntry
{
    public static void Initialize()
    {
        Console.WriteLine($"[CharacterStarter] Loaded: {Characters.CharacterDraft.DisplayName}");
        // 作成したキャラクターやカードの登録処理をここに追加します。
    }
}
