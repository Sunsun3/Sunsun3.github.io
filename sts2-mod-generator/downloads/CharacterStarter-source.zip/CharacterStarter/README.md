# CharacterStarter

STS2 v0.113.1 用の初期テンプレートです。初期化時にログを出力します。プレイ可能なキャラクターの登録は開発者が追加します。

1. .NET 9 SDK と Slay the Spire 2 を用意します。
2. CharacterStarter.csproj のあるフォルダーで `dotnet build -c Release` を実行します。Steam の場所が異なる場合は `dotnet build -c Release "-p:GameDataDir=D:/SteamLibrary/steamapps/common/Slay the Spire 2/data_sts2_windows_x86_64"` のように sts2.dll のあるフォルダーを指定します。
3. bin/Release/net9.0 の CharacterStarter.dll と CharacterStarter.json をゲームの mods/CharacterStarter/ にコピーします。
4. ゲームでModを有効化して起動し、ログで [CharacterStarter] Loaded を確認します。

Characters/CharacterDraft.cs はキャラクター設計の出発点です。ModEntry.cs に登録処理を追加してください。ポートレート等の素材は Assets/Portraits/ で管理できます。
