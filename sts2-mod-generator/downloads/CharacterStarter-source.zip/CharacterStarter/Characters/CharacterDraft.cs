namespace CharacterStarter.Characters;

// キャラクターの設計用データです。ゲームへの登録は次の実装ステップです。
public static class CharacterDraft
{
    public const string Id = "CharacterStarter-Hero";
    public const string DisplayName = "塔の旅人";
    public const int StartingHealth = 70;
}
